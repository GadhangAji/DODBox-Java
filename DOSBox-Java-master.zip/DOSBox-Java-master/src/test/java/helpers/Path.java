/*
 * DOSBox, Scrum.org, Professional Scrum Developer Training
 * Authors: Rainer Grau, Daniel Tobler, Zuehlke Technology Group
 * Copyright (c) 2013 All Right Reserved
 */ 

package helpers;

public class Path {

	public static String Combine(String path1, String path2) {
		return path1 + "\\" + path2;
	}
}
